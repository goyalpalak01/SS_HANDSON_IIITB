//This program will wait to catch SIGSTOP signal
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

void mySig_Handler(int signum)
{
	printf("\nCaught SIGSTOP signal and exiting...\n");
	exit(0);
}
int main()
{
	struct sigaction sa;
	sa.sa_handler = &mySig_Handler;

	sigaction(SIGSTOP,&sa,NULL);
	printf("Hi,My Process ID = %d\n",getpid());
	printf("Waiting to catch SIGSTOP signal\n");

	pause(); //wait for signal
	return 0;
}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 13a.c -o 13a
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./13a
Hi,My Process ID = 6129
Waiting to catch SIGSTOP signal

[1]+  Stopped                 ./13a
*/