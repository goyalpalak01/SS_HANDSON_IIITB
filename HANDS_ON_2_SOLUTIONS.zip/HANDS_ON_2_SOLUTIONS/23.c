#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
int main()
{
	long Max_no_of_FILES,PIPE_SIZE;
	Max_no_of_FILES = sysconf(_SC_OPEN_MAX); //to get configuration info at run time

	printf("Maximum number of files that a process can open at any time = %ld\n",Max_no_of_FILES);

	mknod("myfifopipe",S_IFIFO|0666,0);
	PIPE_SIZE = pathconf("myfifopipe",_PC_PIPE_BUF); //to get configuration values for files
	printf("Maximum number of bytes that can be read atomically to a fifo pipe(PIPE SIZE) = %ld\n", PIPE_SIZE);
	return 0;
}