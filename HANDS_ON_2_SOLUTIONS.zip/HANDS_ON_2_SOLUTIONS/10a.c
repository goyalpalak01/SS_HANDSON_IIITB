//SIGSEGV using sigaction
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

void mySig_Handler(int signum)
{
	printf("Caught SIGSEGV signal!!\n");
	exit(0);
}

int main()
{
	struct sigaction sa;
	sa.sa_handler = &mySig_Handler;

	sigaction(SIGSEGV,&sa,NULL);

	//Generating SIGSEGV signal
	int n;
	printf("Enter any number:\n");
	scanf("%d",n);

	return 0;

}