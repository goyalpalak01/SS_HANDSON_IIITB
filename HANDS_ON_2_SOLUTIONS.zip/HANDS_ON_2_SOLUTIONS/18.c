// This program executes ls -l | grep ^d |wc -l
#include <stdio.h>
#include <unistd.h>

int main()
{
	int fd1[2],fd2[2],ret1,ret2;

	//creating 2 pipes
	ret1 = pipe(fd1);
	if(ret1==-1)
	{
		perror("PIPE1 ERROR");
		return -1;
	}

	ret2 = pipe(fd2);
	if(ret2==-1)
	{
		perror("PIPE2 ERROR");
		return -1;
	}
///////////////////////////////////////////////////////////////
	int pid1 = fork();
	if(pid1==-1)
	{
		perror("FORK ERROR");
		return -1;
	}
	else if(pid1==0)
	{	//It will execute ls -l and put output to pipe1
		close(fd1[0]); //close read end of pipe1
		close(fd2[0]); //close read end of pipe2
		close(fd2[1]); //close e=write end of pipe2

		dup2(fd1[1],1); //duplicate the write end of pipe1 to stdout
		int var = execl("/bin/ls","ls","-l",NULL);
		if(var==-1)
		{
			perror("EXECL ERROR in ls");
			return -1;
		}

	}
	else
	{
		int pid2 = fork();
		if(pid2==-1)
		{
			perror("FORK ERROR");
			return -1;
		}
		else if(pid2==0)
		{	//It will execute grep ^d which takes input from pipe1 and put output to pipe2
			close(fd1[1]);//close write end of pipe1
			close(fd2[0]);//close read end of pipe2
			dup2(fd1[0],0);//duplicate the read end of pipe1 to stdin
			dup2(fd2[1],1); //duplicate write end of pipe2 to stdout

			int var = execl("/bin/grep","grep","^d",NULL);
			if(var==-1)
			{
				perror("EXECL ERROR in grep");
				return -1;
			}

		}
		else
		{
			//It will execute wc -l which takes input from pipe2 and put output to stdout
			close(fd1[0]);//close read end of pipe1
			close(fd1[1]);//close write end of pipe1
			close(fd2[1]);//close write end of pipe2

			dup2(fd2[0],0);//duplicate read end of pipe2 to stdin
			int var = execl("/usr/bin/wc","wc","-l",NULL);
			if(var==-1)
			{
				perror("EXECL ERROR in wc");
				return -1;
			}
		}

	}
	return 0;
}