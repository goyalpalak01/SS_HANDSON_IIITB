//mknod system call
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main()
{
	int ret = mknod("./MyFIFO1",S_IFIFO|0666,0);
	if(ret==-1)
	{
		perror("MKNOD ERROR");
		return -1;
	}
	else
		printf("FIFO Created!!\n");

	return 0;
}
