#include <stdio.h>
#include <unistd.h>

//execl()
int main()
{
	printf("Calling execl() to list the contents...\n");
	
	int ret = execl("/bin/ls","ls","-Rl",NULL);
	if(ret==-1)
	{
		perror("EXECL");
		return 1;
	}
	return 0;
}