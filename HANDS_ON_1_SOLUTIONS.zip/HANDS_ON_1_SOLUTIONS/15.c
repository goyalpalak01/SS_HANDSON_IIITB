#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
extern char **environ;
int main()
{

	char *envVar= *environ;
	printf("*******ENVIRONMENT VARIABLES*******\n");
	while(envVar!=NULL)
	{
		printf("%s\n",envVar);
		printf("--------------------------------------------------------------------------------------------------\n");
		envVar= *(++environ);
	}
	return 0;
}

