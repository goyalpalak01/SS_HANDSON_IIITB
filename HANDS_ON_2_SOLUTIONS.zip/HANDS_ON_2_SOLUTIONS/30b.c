//Program to remove shared memory
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>

int main(int argc, char const *argv[])
{
	int shmid;
	printf("Enter the ID of shared memory segment you want to remove:\n");
	scanf("%d",&shmid);

	int ret = shmctl(shmid,IPC_RMID,0); //IPC_RMID marks segment for destruction
	if(ret==-1)
	{
		perror("SHMCTL ERROR");
		return -1;
	}
	else
	{
		printf("Shared memory segment with ID = %d is removed!!\n",shmid);
	}
	return 0;
} 