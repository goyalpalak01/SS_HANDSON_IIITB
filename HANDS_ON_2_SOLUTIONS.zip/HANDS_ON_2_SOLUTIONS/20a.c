//This program writes on FIFO pipe
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

int main()
{	
	int ret = mkfifo("myfifo20",0666); //create FIFO
	if(ret==-1)
	{
		perror("MKFIFO ERROR");
		return -1;
	}

	int fp = open("myfifo20",O_WRONLY); //open FIFO for writing
	if(fp==-1)
	{
		perror("OPEN FIFO ERROR");
		return -1;
	}
	char msg[]="Hello World!!\n";
	write(fp, msg,strlen(msg)); //write to FIFO
	printf("Message sent: %s\n",msg);

	close(fp);
	return 0;
}