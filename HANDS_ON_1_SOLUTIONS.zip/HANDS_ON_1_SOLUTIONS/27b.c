#include <stdio.h>
#include <unistd.h>

//execlp()
int main()
{
	printf("Calling execlp() to list the contents...\n");
	
	int ret = execlp("ls","ls","-Rl",NULL);
	if(ret==-1)
	{
		perror("EXECLP");
		return 1;
	}
	return 0;
}