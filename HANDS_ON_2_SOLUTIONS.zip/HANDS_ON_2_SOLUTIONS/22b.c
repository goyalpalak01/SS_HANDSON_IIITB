//This program will wait for 10secs to read data from pipe otherwise display "no data available"
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>

int main()
{
	//open pipe for reading
	int fp = open("myfifo22",O_RDONLY|O_NONBLOCK);
	
	fd_set rdfd;
	struct timeval t;
	int retval;

	FD_ZERO(&rdfd);
	FD_SET(fp,&rdfd); //watch fp to see when it has data

	//wait for 10 seconds
	t.tv_sec=10;
	t.tv_usec=0;

	retval = select(5,&rdfd,NULL,NULL,&t);
	if(retval==-1)
	{
		perror("SELECT ERROR");
		return -1;
	}
	else if(retval)
	{
		//Data is available within time
		char buf[80];
		read(fp,buf,sizeof(buf));
		printf("RECEIVED DATA: %s\n",buf);
	}
	else
	{
		printf("No data is available within 10 seconds\n");
	}
	return 0;
}