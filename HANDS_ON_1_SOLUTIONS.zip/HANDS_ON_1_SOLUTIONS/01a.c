//Softlink using system call

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc, char const *argv[])
{
	int fd = open(argv[1], O_CREAT|O_WRONLY|O_TRUNC, 0644);
	char str[] ="Hello World!!";
	write(fd, str, sizeof(str));
	close(fd);


	const char *target = argv[1];
	const char linkfile[]= "./softlink_file.txt";
	int ret = symlink(target,linkfile);
	if(ret==0)

		printf("Softlink created successfully!!\n");
	else
		perror("Error");

	return 0;
}
