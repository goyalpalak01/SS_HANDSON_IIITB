//CLIENT
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <string.h>

int main()
{
	int sockfd_client;
	sockfd_client = socket(AF_INET,SOCK_STREAM,0);
	if(sockfd_client==-1)
	{
		perror("SOCKET ERROR");
		return -1;
	}
	struct sockaddr_in server_addr;
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(9734);
	server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

	printf("Establishing connection with server.....\n");
	int ret = connect(sockfd_client,(struct sockaddr *)&server_addr,sizeof(server_addr));
	if(ret==-1)
	{
		perror("CONNECTION FAILED");
		return -1;
	}
	else
		printf("****CONNECTION ESTABLISHED****\n");
	//////////////////////////////////////////////////////////////////////////////////////
	int num,i=1;
	printf("Enter two numbers you want to add:\n");
	while(i<3)
	{
		scanf("%d",&num);
		write(sockfd_client,&num,sizeof(num));
		i++;
	}
	read(sockfd_client,&num,sizeof(num));
	printf("SUM OF THE NUMBERS = %d\n",num);
	close(sockfd_client);
	printf("EXITING...\n");
	exit(0);
}