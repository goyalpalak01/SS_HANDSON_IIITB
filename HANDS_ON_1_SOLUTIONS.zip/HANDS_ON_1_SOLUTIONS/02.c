#include <stdio.h>

int main()
{
	while(1)
	{
	}

	return 0;
}

/* palak_goyal@Palak:/mnt/e/test_linux/Hands-On1$ gcc Q2.c
 * palak_goyal@Palak:/mnt/e/test_linux/Hands-On1$ ./a.out &
 * [1] 5964
 * palak_goyal@Palak:/mnt/e/test_linux/Hands-On1$ ps u |grep 5964
 * USER       PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
 * palak_g+  5964  100  0.0   2360   584 pts/0    R    17:13   3:16 ./a.out
 *
 * palak_goyal@Palak:/mnt/e/test_linux/Hands-On1$ cat /proc/5964/status |head
 * Name:   a.out
 * Umask:  0022
 * State:  R (running)
 * Tgid:   5964
 * Ngid:   0
 * Pid:    5964
 * PPid:   10
 * TracerPid:      0
 * Uid:    1000    1000    1000    1000
 * Gid:    1000    1000    1000    1000
 *
 * palak_goyal@Palak:/mnt/e/test_linux/Hands-On1$ kill 5964
 * palak_goyal@Palak:/mnt/e/test_linux/Hands-On1$ cat /proc/5964/status |head
 * cat: /proc/5964/status: No such file or directory
 * [1]+  Terminated              ./a.out
 */

