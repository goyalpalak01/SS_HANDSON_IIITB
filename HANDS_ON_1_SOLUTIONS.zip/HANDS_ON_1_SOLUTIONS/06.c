#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>

int main()
{
	char *buffer= (char *) calloc(100, sizeof(char));
    
	// read from stdin --> fd=0
	int cntr = read(0, buffer,sizeof(buffer));
	if(cntr == -1)
		perror("Error while reading:");

	// write to stdout --> fd=1
	int cntw = write(1,buffer,cntr);
	if(cntw == -1)
		perror("Error while writing");

	return 0;
}
