#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>

int main()
{
	struct flock lock;
	int fd=open("file1.txt",O_RDONLY);
	
	//setting lock fields
	lock.l_type=F_RDLCK; //read lock
	lock.l_whence=SEEK_SET;
	lock.l_start=0;
	lock.l_len=0; //to lock till EOF from the start
	lock.l_pid=getpid();

	printf("****Before entering the critical section****\n");
	printf("----ACQUIRING READ LOCK----\n");
	//Acquire lock
	int ret=fcntl(fd,F_SETLKW,&lock);
	//printf("RET VALUE= %d\n",ret);
	if(ret!=-1)
	{

		printf("----ACQUIRED READ LOCK----\n");
		printf("****Process inside critical section***\n");
		printf("Press enter to exit the critical section(unlock the file):\n");
		getchar();
	}
	else
	{
		perror("LOCK ERROR");
		return 0;
	}
	printf("----UNLOCKING-----\n");
	lock.l_type=F_UNLCK;
	fcntl(fd,F_SETLK,&lock); //unlock
	printf("****UNLOCKED------> Process outside critical section****\n");
	printf("****FINISH****\n");
	close(fd);
	return 0;
}

