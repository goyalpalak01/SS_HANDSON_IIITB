#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <sys/stat.h>
#include <stdlib.h>

int main()
{
	int pid = fork(); //create new process

	if(pid==-1)
	{
		perror("FORK ERROR");
		return -1;
	}
	else if(pid!=0)//Parent process
	{
		exit(EXIT_SUCCESS);
	}

	//create new session and process group with session id and process group id same as process id
	int ret = setsid();
	if(ret==-1)
	{
		perror("SET_SID ERROR");
		return -1;
	}

	//change working directory to root
	int ret1 = chdir("/");
	if(ret1==-1)
	{
		perror("CHDIR ERROR");
		return -1;
	}
	//set file mode creation mask
	umask(0);
	printf("Daemon Process running!!!\n");
	sleep(40);
	printf("Daemon Process terminating!!!\n");
	return 0;

}
/* 
palak@palak-VirtualBox:~/SSD_Assignments/Hands-On1$ gcc 30.c
palak@palak-VirtualBox:~/SSD_Assignments/Hands-On1$ ./a.out &
[1] 3919
palak@palak-VirtualBox:~/SSD_Assignments/Hands-On1$ Daemon Process running!!!
Daemon Process terminating!!!

[1]+  Done                    ./a.out
-----------------------------------------------------------------------------------

palak@palak-VirtualBox:~$ ps aux | grep 3920
palak       3920  0.0  0.0   2488    76 ?        Ss   02:34   0:00 ./a.out
palak       3922  0.0  0.0   8900   728 pts/1    S+   02:34   0:00 grep --color=auto 3920
