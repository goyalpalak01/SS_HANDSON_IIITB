#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc,const char *argv[])
{
	int count=1;
	while(1)
	{
		if(count<=5)
		{
			const char *filename= argv[count];
			int fd =creat(filename,0644);
			if(fd==-1)
				perror("Error");
			
			count++;
		}
	}
	return 0;
}
/*OUTPUT:
 * palak_goyal@Palak:/mnt/e/test_linux/Hands-On1$ gcc Q5.c
 * palak_goyal@Palak:/mnt/e/test_linux/Hands-On1$ ./a.out file1.txt file2.txt file3.txt file4.txt file5.txt &
 * [1] 160
 *
 * palak_goyal@Palak:/mnt/e/test_linux/Hands-On1$ cd /proc/160/fd
 *
 * palak_goyal@Palak:/proc/160/fd$ ls -l
 * total 0
 * lrwx------ 1 palak_goyal palak_goyal 64 Sep 12 22:40 0 -> /dev/pts/1
 * lrwx------ 1 palak_goyal palak_goyal 64 Sep 12 22:40 1 -> /dev/pts/1
 * lrwx------ 1 palak_goyal palak_goyal 64 Sep 12 22:40 2 -> /dev/pts/1
 * l-wx------ 1 palak_goyal palak_goyal 64 Sep 12 22:40 3 -> /mnt/e/test_linux/Hands-On1/file1.txt
 * l-wx------ 1 palak_goyal palak_goyal 64 Sep 12 22:40 4 -> /mnt/e/test_linux/Hands-On1/file2.txt
 * l-wx------ 1 palak_goyal palak_goyal 64 Sep 12 22:40 5 -> /mnt/e/test_linux/Hands-On1/file3.txt
 * l-wx------ 1 palak_goyal palak_goyal 64 Sep 12 22:40 6 -> /mnt/e/test_linux/Hands-On1/file4.txt
 * l-wx------ 1 palak_goyal palak_goyal 64 Sep 12 22:40 7 -> /mnt/e/test_linux/Hands-On1/file5.txt
 */

