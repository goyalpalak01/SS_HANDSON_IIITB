#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
	//Ignore SIGINT signal
	signal(SIGINT,SIG_IGN);

	printf("Any interrupt from keyboard(SIGINT) will be ignored(Try pressing Ctrl+C)\n");
	sleep(10);

	printf("\nResetting SIGINT action to default:\n");
	//Reset the default action
	signal(SIGINT,SIG_DFL);

	sleep(10);
	return 0;

}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 09.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out
Any interrupt from keyboard(SIGINT) will be ignored(Try pressing Ctrl+C)
^C
^C
Resetting SIGINT action to default:
^C
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ 

*/
