#include <sys/time.h>
#include <sys/resource.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
	int retval;
	struct rlimit limit;

	retval = getrlimit(RLIMIT_CPU,&limit);
	if(retval==-1)
	{
		perror("GETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Amount of CPU time that a process can consume:\n");
		printf("Soft Limit : %lu seconds\n",limit.rlim_cur);
		printf("Hard Limit : %lu seconds\n",limit.rlim_max);
	}
	return 0;
}
