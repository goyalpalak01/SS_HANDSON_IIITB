#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
int main(int argc, const char* argv[])
{
	
	int fd = open("data.txt",O_RDWR|O_CREAT|O_TRUNC,0744);
	if(fd==-1)
	{
		perror("OPEN ERROR");
		return 1;
	}
	//Write 10B to file
	
	int ret = write(fd,"TEST MESSG",10);
	if(ret==-1)
	{
		perror("WRITE ERROR");
		return 1;
	}

	//Move file pointer by 10B
	
	int pos= lseek(fd,10,SEEK_CUR); //sets file pointer to current loc +10
	if(pos==-1)
	{
		perror("ERROR LSEEK");
		return 1;
	}
	else
	{
		printf("After moving pointer by 10B,current position of file pointer: %d\n",pos);
	}
	//Write 10B to file
	int ret1 = write(fd,"TEST MESSG",10);
	if(ret1==-1)
	{
		 perror("WRITE ERROR");
		 return 1;
       	}
	else
	{
		printf("After writing 10B,current position of file pointer: %ld\n",lseek(fd,0,SEEK_CUR));
	}

	close(fd);
	return 0;
}
/* OUTPUT of od command:
 *
 * palak_goyal@Palak:/mnt/e/test_linux/Hands-On1$ od -An -c data.txt
 *    T   E   S   T       M   E   S   S   G  \0  \0  \0  \0  \0  \0
 *      \0  \0  \0  \0   T   E   S   T       M   E   S   S   G
 *
 */      
