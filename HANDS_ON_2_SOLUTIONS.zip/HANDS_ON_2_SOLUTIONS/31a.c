//Binary Semaphore
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
	
	int semid;
	union semun {
		int val;	
	};
	//Create/Retrieve a semaphore set
	semid = semget((key_t)1111,1,IPC_CREAT|0666);//1 implies no. of semaphore in a set
	if(semid==-1)
	{
		perror("SEMGET ERROR");
		return -1;
	}
	else
		printf("Binary Semaphore ID = %d\n",semid);

	//Initialise the binary semaphore value with 1
	union semun arg;
	arg.val=1;
	int ret = semctl(semid,0,SETVAL,arg);
	if(ret==-1)
	{
		perror("SEMCTL SETVAL ERROR");
		return -1;
	}
	else
	{	
		//Print the current value of Semaphore
		int val =semctl(semid,0,GETVAL,arg);
		printf("Semaphore initialised with value = %d\n",val);
	}
	return 0;	

}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 31a.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out

Binary Semaphore ID = 0
Semaphore initialised with value = 1

palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ipcs -s

------ Semaphore Arrays --------
key        semid      owner      perms      nsems     
0x00000457 0          palak      666        1        
*/
