#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>

int main()
{       
	char ch;
	int fd1,ret1,ret2;
	char msg[]= "This is line 1\nThis is line 2\n";
	//source file                                                       
	fd1 = open("sample.txt",O_RDWR|O_CREAT,0744);
	if(fd1==-1)
	{
		perror("SOURCE FILE OPEN ERROR");
		return 1;
	}
	write(fd1,&msg,sizeof(msg));
	lseek(fd1,-1*sizeof(msg),SEEK_CUR); //to update file pointer bck to start

	while((ret1 = read(fd1,&ch,1))>0)
	{
		ret2 = write(1,&ch,1);
		if(ch=='\n')
			write(1,"NEW LINE ENCOUNTERED\n", sizeof("NEW LINE ENCOUNTERED\n"));
	}
	close(fd1);
	return 0;
}
