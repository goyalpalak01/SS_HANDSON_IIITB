//Writing to shared memory in Read Write mode and in Read only mode
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
int main()
{
	int shmid = shmget((key_t)3333,1024,IPC_CREAT|0666); //create/retrieve a shared memory segment of 1024 bytes
	if(shmid==-1)
	{
		perror("SHMGET ERROR");
		return -1;
	}
	printf("Shared memory segment ID = %d\n",shmid);

	//Attach the shm segment to the address space of calling process to enable access to shm
	//Returns the pointer to the first byte of shm
	
	char *ptr = (char *)shmat(shmid,NULL,0); //NULL allows the system to choose address on its own
	if(ptr==(char *)-1)
	{
		perror("SHMAT ERROR");
		return -1;
	}
	else
		printf("Shared Memory attached at address %p\n",ptr);

	//writing data to shm
	sprintf(ptr,"Hello World!!"); //write to ptr
	
	printf("Data written to shared memory : %s\n",ptr);

	int ret = shmdt(ptr); //detach the shm segment from address space of calling process
	if(ret==-1)
	{
		perror("SHMDT ERROR");
		return -1;
	}
	else
		printf("Shared memory detached from the process!!!\n");
	
	sleep(2);

	//Reattach the shared memory segment in Read-Only mode
	ptr = (char *)shmat(shmid,NULL,SHM_RDONLY); //NULL allows the system to choose address on its own
	if(ptr==(char *)-1)
	{
		perror("SHMAT ERROR");
		return -1;
	}
	else
		printf("\nShared Memory reattached at address %p in Read-Only mode\n",ptr);

	//writing data to new address
	printf("Writing some data to shared memory......\n");
	sprintf(ptr,"Bye World!!"); //write to ptr
	

	return 0 ;

}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 30a.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out
Shared memory segment ID = 163852
Shared Memory attached at address 0x7f72adbb7000
Data written to shared memory : Hello World!!
Shared memory detached from the process!!!

Shared Memory reattached at address 0x7f72adbb7000 in Read-Only mode
Writing some data to shared memory......
Segmentation fault (core dumped)
*/










