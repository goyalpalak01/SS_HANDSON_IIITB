#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#define BUF_SIZE 1024
int main()
{       
	char buffer[BUF_SIZE];
	int fd1,fd2,ret1,ret2;
	char msg[]="This message will be copied to destination file\n";
	//source file                                                        
	fd1 = open("source.txt",O_RDWR|O_CREAT|O_TRUNC,0744);
	if(fd1==-1){
		perror("SOURCE FILE OPEN ERROR");
		return 1;
	}
	write(fd1,&msg,sizeof(msg));
	lseek(fd1,-1*sizeof(msg),SEEK_CUR); //to update file pointer bck to start
	
	//destination file
	fd2= open("destination.txt",O_WRONLY|O_CREAT,0744);
	if(fd2==-1){
		perror("DESTINATION FILE OPEN ERROR");
		return 2;
	}

	//copy
	
	while((ret1 = read(fd1,&buffer,BUF_SIZE))>0)
	{	
		
		ret2 = write(fd2,&buffer,ret1);
		
		
	}
	
	close(fd1);
	close(fd2);
	return 0;
}

