#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
int main(int argc, const char *argv[])
{
	
	int oldfd = open("dup2.txt",O_RDWR|O_CREAT|O_APPEND,0666);
	if(oldfd==-1)
	{
		perror("ERROR IN OPEN");
		return 1;
	}
	int newfd = dup2(oldfd,4);
	if(newfd==-1)
	{
		perror("ERROR IN DUP2");
		return 1;
	}
	//writing via oldfd
	int ret1=write(oldfd,"HELLO ",sizeof("HELLO "));
	if(ret1==-1)
	{
		perror("ERROR IN WRITE");
		return 1;
	}
	else
	{
		printf("UPDATED VIA OLDFD\n");
	}
	//writing via newfd
	int ret2=write(newfd,"WORLD ",sizeof("WORLD "));
	if(ret2==-1)
	{
		perror("ERROR IN WRITE");
		return 1;
	}
	else
	{
		 printf("UPDATED VIA NEWFD\n");
	}
	close(oldfd);
	close(newfd);
	return 0;
}
