//This program will write to the pipe
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

int main()
{
	//create a pipe
	int ret = mknod("myfifo22",S_IFIFO|0666,0);
	if(ret==-1)
	{
		perror("MKNOD ERROR");
		return -1;
	}
	//open pipe for writing
	int fp = open("myfifo22",O_WRONLY);

	char readbuf[80];
	printf("Enter the data you want to write on pipe\n");
	read(0,readbuf,sizeof(readbuf)); //read from stdin into readbuf
	write(fp,readbuf,sizeof(readbuf)); //write from readbuf into pipe

	close(fp);
	return 0;
}