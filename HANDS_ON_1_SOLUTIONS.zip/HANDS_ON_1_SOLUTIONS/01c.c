#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc, const char *argv[])
{	
	int ret = mkfifo(argv[1],0666);
	if(ret==-1)
	{
		perror("ERROR MKNOD");
		return -1;
	}
	else
		printf("FIFO created successfully!!\n");
	return 0;
}
