#include <unistd.h>
#include <stdio.h>

int main()
{
	printf("****SYSTEM LIMITS****\n");
	printf("Maximum length of args to exec() family of functions = %ld\n",sysconf(_SC_ARG_MAX));
	printf("Maximum number of simultaneous processes per user ID = %ld\n",sysconf(_SC_CHILD_MAX));
	printf("The number of clock ticks per second = %ld\n",sysconf(_SC_CLK_TCK));
	printf("Maximum number of files that a process can have open at any time = %ld\n",sysconf(_SC_OPEN_MAX));
	printf("Size of a page = %ld bytes\n",sysconf(_SC_PAGESIZE));
	printf("The  number of pages of physical memory = %ld\n",sysconf(_SC_PHYS_PAGES));
	printf("The number of currently available pages of physical memory = %ld\n",sysconf(_SC_AVPHYS_PAGES));

	
	return 0;
}