#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <stdio.h>
int main()
{	
	clock_t start,end;
	double time_taken;

	start = clock(); //get CPU time(clocks)
	//printf("%d\n",start);
	getpid();
	end = clock();
	//printf("%d\n",end);
	time_taken = ((double)(end-start)) / CLOCKS_PER_SEC; // int CLOCKS_PER_SEC
	printf("Time taken to execute getpid system call : %lf seconds\n",time_taken);

	return 0;
}