#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>

int main()
{
	//generate key for message queue
	key_t keyval;
	keyval = ftok("./24.c",1);
	if(keyval==-1)
	{
		perror("FTOK ERROR");
		return -1;
	}
	else
		printf("Key generated for the message queue = %ld\n",(long) keyval);

	//create a message queue using above key

	int qid;
	qid = msgget(keyval,IPC_CREAT|0666);
	if(qid==-1)
	{
		perror("MSGGET ERROR");
		return -1;
	}
	else
		printf("Message Queue ID = %d\n",qid);

	return 0;
}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ipcs -q

------ Message Queues --------
key        msqid      owner      perms      used-bytes   messages    
0x0105050b 0          palak      666        0            0   
*/