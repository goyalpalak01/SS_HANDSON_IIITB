#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
	int pipefd[2],ret;

	ret = pipe(pipefd);
	if(ret==-1)
	{
		perror("PIPE ERROR");
		return -1;
	}

	int pid = fork(); //create new process
	if(pid==-1)
	{
		perror("FORK ERROR");
		return -1;
	}
	else if(pid==0)
	{
		//Child
		close(pipefd[1]);//close write end of pipe
		close(0); //close stdin of child
		fcntl(pipefd[0],F_DUPFD,0); //duplicate read end of pipe to stdin
	
		int var = execl("/usr/bin/wc","wc",NULL);
		if(var==-1)
		{
			perror("EXECL ERROR in Child");
			return -1;
		}

	}
	else
	{
		//Parent
		close(pipefd[0]); //close read end of pipe
		close(1); //close stdout of parent
		fcntl(pipefd[1],F_DUPFD,1); //duplicate write end of pipe to stdout

		int var = execl("/bin/ls","ls","-l",NULL);
		if(var==-1)
		{
			perror("EXECL ERROR in Parent");
			return -1;
		}
	}
	return 0;
}