//Hardlink using system call

#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char const *argv[])
{
	int fd = open(argv[1], O_CREAT|O_WRONLY|O_TRUNC, 0744);
	char str[] ="Hello World!!";
	write(fd, str, sizeof(str));
	close(fd);

	const char *target = argv[1];
	const char linkfile[]= "./hardlink_file.txt";
	int ret = link(target,linkfile);
	if(ret==0)
		printf("Hardlink created successfully!!\n");
	else
		perror("Error");

	return 0;
}

