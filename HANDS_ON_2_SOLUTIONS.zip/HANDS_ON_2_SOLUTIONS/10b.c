//SIGINT using sigaction
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

void mySig_Handler(int signum)
{
	printf("\nCaught SIGINT signal and exiting...\n");
	exit(0);
}

int main()
{
	struct sigaction sa;
	sa.sa_handler = &mySig_Handler;

	sigaction(SIGINT,&sa,NULL);

	//Generating SIGINT signal
	printf("Press Ctrl+C to generate SIGINT:\n");
	sleep(10);

	return 0;

}