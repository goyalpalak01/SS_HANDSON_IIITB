//receiver
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <string.h>

int main()
{
	int qid = msgget((key_t)1234,IPC_CREAT|0666); //get message queue id
	if(qid==-1)
	{
		perror("MSGGET ERROR");
		return -1;
	}
	//create message structure to store the retrieved message
	struct msgbuf{
		long mtype;
		char mtext[100];
	}msg;

	//receive message
	int ret = msgrcv(qid,&msg,100,10,IPC_NOWAIT);
	if(ret==-1)
	{
		perror("MSGRCV ERROR");
		return -1;
	}
	else
	{	
		printf("Bytes of message received : %d\n",ret);
		printf("Received message : %s\n",msg.mtext);
	}
	return 0;
}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ipcs -q

------ Message Queues --------
key        msqid      owner      perms      used-bytes   messages    
0x000004d2 0          palak      666        0            0           

palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 27b.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out
MSGRCV ERROR: No message of desired type
*/