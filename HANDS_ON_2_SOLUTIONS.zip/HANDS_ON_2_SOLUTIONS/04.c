//TSC measures time at very high accuracy. It increments at every CPU tick

#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>

unsigned long long int rdtsc()
{
	unsigned long long int dst;
	__asm__ __volatile__("rdtsc":"=A"(dst));
	return dst;
}

int main()
{
	unsigned long long int start,end;
	int i;
	start = rdtsc();
	//printf("START = %llu",start);

	for(i=1;i<=100;i++)
	{
		getppid();
	}
	end = rdtsc();
	//printf("END = %llu",end);

	printf("Time taken to execute 100 getppid() system calls = %llu clock ticks \n",(end-start));
	return 0;
}