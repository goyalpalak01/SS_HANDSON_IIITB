#include <stdio.h>
#include <sys/resource.h>
#include <unistd.h>
#include <errno.h>

int main(int argc, char const *argv[])
{	

	int priority = getpriority(PRIO_PROCESS,0); //PRIO_PROCESS - priority of process , 0 implies calling process
	printf("Before modifying: Priority of this process is %d\n",priority);

	errno=0;
	int new_priority = nice(10);// nice(x) ===> old nice value +x
	if(errno>0)
		perror("NICE ERROR");
	else
	printf("After modifying: Priority of this process is %d\n",new_priority);

	return 0;
}
