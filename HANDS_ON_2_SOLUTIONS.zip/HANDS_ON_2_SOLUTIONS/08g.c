//SIGPROF = Profiling timer expired (man 7 signal)
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>

void handler_func(int signum)
{
	if(signum == SIGPROF)
		printf("Caught Signal SIGPROF!!!\n");
	else
		printf("Invalid signal\n");
}

int main()
{
	typedef void (*sighandler_t)(int);

	signal(SIGPROF,(sighandler_t)handler_func); //to change the disposition of signal(to determine how process behaves on getting signal)

	
	struct itimerval timer;
	timer.it_value.tv_sec = 3; //seconds
	timer.it_value.tv_usec = 0; //microseconds

	//set periodic interval for timer to expire
	timer.it_interval.tv_sec =1;
	timer.it_interval.tv_usec =0;

	setitimer(ITIMER_PROF,&timer,NULL);//set interval timer

	while(1);
	return 0;

}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 8g.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out
Caught Signal SIGPROF!!!
Caught Signal SIGPROF!!!
Caught Signal SIGPROF!!!
Caught Signal SIGPROF!!!
^C
*/