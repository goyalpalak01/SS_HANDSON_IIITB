#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
int main(int argc, const char *argv[])
{	
	
	int fd = open ("mode.txt",O_WRONLY|O_CREAT,0744);
	if(fd==-1)
	{
		perror("OPEN ERROR");
		return 1;
	}
	int open_mode = fcntl(fd,F_GETFL)& O_ACCMODE ;// O_ACCMODE = 011
	if(open_mode==0)
		printf("Access mode of file :Read Only (O_RDONLY)\n");
	else if(open_mode==1)
		printf("Access mode of file :Write Only (O_WRONLY)\n");
	else if(open_mode==2)
		printf("Access mode of file :Read-Write (O_RDWR)\n");
	else
		printf("Unknown Access Mode\n");	
	close(fd);
	return 0;
}

