#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

int main()
{
	struct ticket
	{
		int ticket_no;
	};
	int fd = open("ticketNumber.txt",O_RDWR|O_CREAT,0744);
	if(fd==-1)
	{
		perror("OPEN ERROR");
		return 1;
	}
	struct ticket t;
	t.ticket_no = 0; //initially ticket no =0
	int ret=write(fd,&t,sizeof(t));	
	if(ret==-1)
	{
		perror("WRITE ERROR");
		
	}
	close(fd);
	return 0;
}
