//Remove message queue
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <time.h>

int main()
{
	int qid;
	printf("Enter message queue ID you want to remove :\n");
	scanf("%d",&qid);

	int ret = msgctl(qid,IPC_RMID,NULL);
	if(ret==-1)
	{
		perror("MSGCTL ERROR");
		return -1;
	}
	else
	{
		printf("Message queue with ID %d is removed !!\n",qid);
	}
	return 0;
}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ipcs -q

------ Message Queues --------
key        msqid      owner      perms      used-bytes   messages    
0x000004d2 0          palak      666        0            0           
0x0000162e 1          palak      664        0            0           

palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 29.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out
Enter message queue ID you want to remove :
1
Message queue with ID 1 is removed !!
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ipcs -q

------ Message Queues --------
key        msqid      owner      perms      used-bytes   messages    
0x000004d2 0          palak      666        0            0           

*/