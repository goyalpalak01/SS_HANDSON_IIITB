#include <stdio.h>
#include <unistd.h>

int main()
{
	int pid;
	pid = fork();

	if(pid>0)
	{
		printf("Parent process here:\n");
		printf("My ID : %d\n",getpid());
		printf("My Child ID : %d\n",pid);
	}
	else if(pid==0)
	{
		printf("Child process here:\n");
		printf("My ID : %d\n",getpid());
		printf("My Parent ID : %d\n",getppid());
	}
	else if(pid==-1)
		perror("FORK ERROR");

	return 0;
}