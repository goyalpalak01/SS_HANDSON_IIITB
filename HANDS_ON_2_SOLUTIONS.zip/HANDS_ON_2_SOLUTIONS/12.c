#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <stdlib.h>
int main()
{
	int pid = fork(); //create child process

	if(pid==-1)
	{
		perror("FORK ERROR");
		return -1;
	}
	else if(pid==0)
	{	//Child Process
		printf("Hi, Child here!!\n");
		printf("Sending SIGKILL signal to Parent with ID = %d to terminate it!!\n",getppid());

		kill(getppid(),SIGKILL);
		sleep(5);
		printf("New Parent ID after killing original parent = %d\n",getppid());
		sleep(1);
		printf("Child Terminated!\n");
		

	}
	else
	{	//Parent Process
		printf("Hi, Parent here with ID = %d\n",getpid());
		sleep(3);
	}
	exit(0);
}
/*alak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 12.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out
Hi, Parent here with ID = 4230
Hi, Child here!!
Sending SIGKILL signal to Parent with ID = 4230 to terminate it!!
Killed
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ New Parent ID after killing original parent = 1184
Child Terminated!
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ 
*/
