#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
	int fd,pid;
	

	fd = open("dummy.txt",O_RDWR|O_CREAT|O_TRUNC,0666);
	if(fd==-1)
	{
		perror("OPEN ERROR");
		return 1;
	}

	pid = fork();

	if(pid>0)
	{
		//Parent process
		int ret = write(fd,"Written by Parent\n",sizeof("Written by Parent\n"));
		if(ret==-1)
		{
			perror("WRITE ERROR in PARENT");
			return 2;
		}
		
	}
	else if(pid==0)
	{
		//Child process
		int ret1 = write(fd,"Written by Child\n",sizeof("Written by Child\n"));
		if(ret1==-1)
		{
			perror("WRITE ERROR in Child");
			return 3;
		}
	}
	else
		perror("FORK ERROR");

	return 0;
}
/*palak@palak-VirtualBox:~/SSD_Assignments/Hands-On1$ cat dummy.txt 
Written by Parent
Written by Child
*/