//This is server process
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

int main()
{
	
	//open clientFIFO for reading
	int fp_client = open("clientFIFO",O_RDONLY);
	if(fp_client==-1)
	{
		perror("OPEN CLIENTFIFO ERROR");
		return -1;
	}
	char readbuf[100];

	//read data from clientFIFO
	read(fp_client,readbuf,sizeof(readbuf));
	printf("SERVER HERE: MESSAGE RECEIVED FROM CLIENT = %s\n",readbuf);

	close(fp_client);

	/*/////////////////////////////////////////////////////////////////////////////*/

	//open serverFIFO for writing
	int fp_server = open("serverFIFO",O_WRONLY);
	if(fp_server==-1)
	{
		perror("OPEN SERVERFIFO ERROR");
		return -1;
	}
	//write to serverFIFO
	char msg[]="Hello Client!! Server here\n";

	write(fp_server,msg,strlen(msg));
	printf("SERVER HERE: MESSAGE SENT TO CLIENT\n");
	close(fp_server);

	return 0;

}