//sender
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <string.h>
int main()
{
	int qid = msgget((key_t)1234,IPC_CREAT|0666); //get message queue id
	if(qid==-1)
	{
		perror("MSGGET ERROR");
		return -1;
	}
	//create message structure
	struct msgbuf{
		long mtype;
		char mtext[100];
	}msg;

	//Load up msg with data
	strcpy(msg.mtext,"Hi, this is my first message!!");
	msg.mtype =10; //any positive integer
	

	//send message
	int result = msgsnd(qid, &msg,strlen(msg.mtext),0);
	if(result==-1)
	{
		perror("MSGSND ERROR");
		return -1;
	}
	else
	{
		printf("Message sent successfully!!\n");
	}
	return 0;
}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 26.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out
Message sent successfully!!
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ipcs -q

------ Message Queues --------
key        msqid      owner      perms      used-bytes   messages    
0x000004d2 0          palak      666        30           1           
*/
