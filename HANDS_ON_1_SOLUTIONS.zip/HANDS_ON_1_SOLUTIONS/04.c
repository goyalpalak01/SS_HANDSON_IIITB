#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc, const char *argv[])
{
	const char *filename=argv[1];
	int fd;
	fd = open(filename,O_RDWR|O_CREAT|O_EXCL,0644);
	if(fd==-1)
		perror("Error");
	else
		printf("File opened/created\n");
	close(fd);
	return 0;
}
