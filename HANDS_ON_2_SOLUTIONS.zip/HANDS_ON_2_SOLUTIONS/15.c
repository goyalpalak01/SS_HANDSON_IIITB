#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

int main()
{
	int pipefd[2],ret;
	char buf[]="Hello World!!\n";
	char read_buf[30];

	ret = pipe(pipefd); //creates a pipe and return two fds in pipefd array
	if(ret==-1)
	{
		perror("PIPE ERROR");
		return -1;
	}

	int pid = fork(); //creates child process
	if(pid==-1)
	{
		perror("FORK ERROR");
		return -1;
	}
	else if(pid==0) //Child process
	{
		close(pipefd[1]); //close writing end of pipe
		int bytes_read = read(pipefd[0],read_buf,sizeof(read_buf)); //read from the pipe
		printf("CHILD HERE : RECEIVED DATA FROM PARENT --> %s\n",read_buf);
		exit(0);

	}
	else //Parent process
	{
		close(pipefd[0]); //close reading end of pipe
		write(pipefd[1],buf,strlen(buf)); //writes to pipe
		printf("PARENT HERE : DATA SENT TO CHILD\n");
		
	}
	return 0; 
}