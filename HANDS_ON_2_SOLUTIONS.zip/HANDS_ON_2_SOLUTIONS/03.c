#include <sys/time.h>
#include <sys/resource.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
	int retval;
	struct rlimit limit;

	limit.rlim_cur=1; //soft limit
	limit.rlim_max=1; //hard limit

	retval= setrlimit(RLIMIT_CPU,&limit);
	if(retval==-1)
	{
		perror("SETRLIMIT ERROR");
		return -1;
	}
	else
	{
		printf("Modified RLIMIT for RLIMIT_CPU :\n");
		printf("Soft Limit = %lu second\n", limit.rlim_cur);
		printf("Hard Limit = %lu second\n", limit.rlim_max);
	}
	return 0;
}