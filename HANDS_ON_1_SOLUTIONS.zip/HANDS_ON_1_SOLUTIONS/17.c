#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
int main()
{
	struct ticket
	{
		int ticketNumber;
	};
	struct ticket t;
	int fd=open("ticketNumber.txt",O_RDWR);
	if(fd==-1)
	{
		perror("OPEN ERROR");
		close(fd);
		return -1;
	}
	
	struct flock lock;
	lock.l_type=F_WRLCK;
	lock.l_whence=SEEK_SET;
	lock.l_start=0;
	lock.l_len=0;
	lock.l_pid=getpid();
	//reading current ticket number
	read(fd,&t,sizeof(t));
	printf("*****WAITING TO BOOK TICKETS*****\n");
	fcntl(fd,F_SETLKW,&lock);//acquired lock
	printf("*****BOOKING IN PROGRESS*****\n");
	t.ticketNumber++;//incrementing the current ticket number
	printf("YOUR TICKET NUMBER = %d\n",t.ticketNumber);
	lseek(fd,-1*sizeof(t),SEEK_CUR);//updating the file pointer to the start
	write(fd,&t,sizeof(t));//updating file with new ticket number
	printf("Press Enter to book the ticket:\n");
	getchar();
	lock.l_type=F_UNLCK;
	fcntl(fd,F_SETLK,&lock);
	printf("*****TICKET BOOKED*****\n");
	close(fd);
	return 0;
}



