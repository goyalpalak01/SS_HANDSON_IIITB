//mkfifo library function
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main()
{
	int ret = mkfifo("./MyFIFO2",0666);
	if(ret==-1)
	{
		perror("MKFIFO ERROR");
		return -1;
	}
	else
		printf("FIFO Created!!\n");

	return 0;
}
