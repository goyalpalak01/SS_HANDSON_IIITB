#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

int main()
{
	printf("Fork starting!!\n");

	int n;
	int pid = fork();
	switch(pid)
	{
		case -1:
			perror("FORK ERROR");
			exit(1);
		case 0:
		//child process

			for(n=1;n<=5;n++)
			{
				printf("CHILD HERE with PARENT ID = %d\n",getppid());
				sleep(5);
			}
			printf("CHILD PROCESS %d TERMINATED \n",getpid());
			break;
		default:
		//Parent process
			for(n=1;n<=2;n++)
			{
				printf("PARENT HERE!!!\n");
			}
			printf("PARENT PROCESS %d TERMINATED\n",getpid());
			break;
	}
	return 0;
}
/*
palak@palak-VirtualBox:~/SSD_Assignments/Hands-On1$ gcc 24.c
palak@palak-VirtualBox:~/SSD_Assignments/Hands-On1$ ./a.out
Fork starting!!
PARENT HERE!!!
PARENT HERE!!!
PARENT PROCESS 6280 TERMINATED
CHILD HERE with PARENT ID = 6280
palak@palak-VirtualBox:~/SSD_Assignments/Hands-On1$ CHILD HERE with PARENT ID = 1189
CHILD HERE with PARENT ID = 1189
CHILD HERE with PARENT ID = 1189
CHILD HERE with PARENT ID = 1189
CHILD PROCESS 6281 TERMINATED 

palak@palak-VirtualBox:~/SSD_Assignments/Hands-On1$ ps aux |grep 1189
palak       1189  0.0  0.2  18732  9692 ?        Ss   21:19   0:00 /lib/systemd/systemd --user (child process adopted by systemd)
*/