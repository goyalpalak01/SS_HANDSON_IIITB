#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <time.h>

int main()
{
	//create a new message queue
	int qid = msgget((key_t)5678,IPC_CREAT|0666);
	if(qid==-1)
	{
		perror("MSGGET ERROR");
		return -1;
	}
	printf("Message queue ID: %d\n",qid);

	struct msqid_ds qinfo;

	//Get current permission of queue
	int ret = msgctl(qid,IPC_STAT,&qinfo); //to perform control operations on message queue
	if(ret==-1)
	{
		perror("MSGCTL ERROR");
		return -1;
	}
	else
	{
		printf("Current permission of the queue : 0%o\n",qinfo.msg_perm.mode);
	}

	// Set the permission of queue
	qinfo.msg_perm.mode = 436; //0664 in octal
	msgctl(qid,IPC_SET,&qinfo);

	//Retrieve modified permission
	int ret1= msgctl(qid,IPC_STAT,&qinfo); //to perform control operations on message queue
	if(ret1==-1)
	{
		perror("MSGCTL ERROR");
		return -1;
	}
	else
	{
		printf("Modified permission of the queue : 0%o\n",qinfo.msg_perm.mode);
	}
	return 0;
}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 28.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out
Message queue ID: 1
Current permission of the queue : 0666
Modified permission of the queue : 0664
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ipcs -q

------ Message Queues --------
key        msqid      owner      perms      used-bytes   messages    
0x000004d2 0          palak      666        0            0           
0x0000162e 1          palak      664        0            0      
*/