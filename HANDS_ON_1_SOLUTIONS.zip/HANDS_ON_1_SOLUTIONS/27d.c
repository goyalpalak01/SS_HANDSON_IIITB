#include <stdio.h>
#include <unistd.h>

//execv()
int main()
{
	char * argv[]={"ls","-Rl",NULL};
	printf("Calling execv() to list the contents...\n");
	
	int ret = execv("/bin/ls",argv);
	if(ret==-1)
	{
		perror("EXECV");
		return 1;
	}
	return 0;
}