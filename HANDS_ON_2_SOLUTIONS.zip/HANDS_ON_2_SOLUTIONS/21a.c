//This is client process
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

int main()
{
	//create clientFIFO for sending data from client to server
	int ret = mknod("clientFIFO",S_IFIFO|0666,0);
	if(ret==-1)
	{
		perror("CLIENTFIFO ERROR");
		return -1;
	}
	//create serverFIFO for sending data from server to client
	int ret1 = mknod("serverFIFO",S_IFIFO|0666,0);
	if(ret1==-1)
	{
		perror("SERVERFIFO ERROR");
		return -1;
	}
	/*///////////////////////////////////////////////////////////////////////////*/

	//open clientFIFO for writing
	int fp_client = open("clientFIFO",O_WRONLY);
	if(fp_client==-1)
	{
		perror("OPEN CLIENTFIFO ERROR");
		return -1;
	}
	char msg[]="Hello Server!! Client here\n";
	//write to clientFIFO
	write(fp_client,msg,strlen(msg));
	printf("CLIENT HERE: MESSAGE SENT TO SERVER\n");
	close(fp_client);
	
	/*/////////////////////////////////////////////////////////////////////////////////////////////*/

	//open serverFIFO for reading
	int fp_server = open("serverFIFO",O_RDONLY);
	if(fp_server==-1)
	{
		perror("OPEN SERVERFIFO ERROR");
		return -1;
	}
	char readbuf[100];
	//read from serverFIFO
	read(fp_server,readbuf,sizeof(readbuf));
	printf("CLIENT HERE: MESSAGE RECEIVED FROM SERVER = %s\n",readbuf);

	close(fp_server);

	return 0;

}