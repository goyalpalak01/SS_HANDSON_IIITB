#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

int main()
{
	printf("Fork starting!!\n");

	int n;
	int pid = fork();
	switch(pid)
	{
		case -1:
			perror("FORK ERROR");
			exit(1);
		case 0:
		//child process
			for(n=1;n<=3;n++)
			{
				printf("CHILD HERE!!!\n");
			}
			printf("CHILD PROCESS %d TERMINATED \n",getpid());
			break;
		default:
		//Parent process
			for(n=1;n<=6;n++)
			{
				printf("PARENT HERE!!!\n");
			}
			sleep(15);
			printf("PARENT PROCESS %d TERMINATED\n",getpid());
			break;
	}
	return 0;
}
/* palak@palak-VirtualBox:~/SSD_Assignments/Hands-On1$ ./a.out
Fork starting!!
PARENT HERE!!!
PARENT HERE!!!
PARENT HERE!!!
PARENT HERE!!!
PARENT HERE!!!
PARENT HERE!!!
CHILD HERE!!!
CHILD HERE!!!
CHILD HERE!!!
CHILD PROCESS 5369 TERMINATED 

(on new window)
palak@palak-VirtualBox:~$ ps aux |grep 5369
palak       5369  0.0  0.0      0     0 pts/0    Z+   22:32   0:00 [a.out] <defunct>

PARENT PROCESS 5368 TERMINATED


*/
