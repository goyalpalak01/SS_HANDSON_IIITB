//Send SIGSTOP signal to other process
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
	int pid_to_kill = atoi(argv[1]);

	int ret = kill(pid_to_kill,SIGSTOP);
	if(ret==-1)
	{
		perror("KILL ERROR");
		return -1;
	}
	else
		printf("SENT SIGSTOP SIGNAL TO THE PROCESS %d\n",pid_to_kill);
	return 0;
}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 13b.c -o 13b
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./13b 6129
SENT SIGSTOP SIGNAL TO THE PROCESS 6129
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ 
*/