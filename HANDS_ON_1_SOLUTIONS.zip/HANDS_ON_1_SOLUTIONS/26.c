#include <unistd.h>
#include <stdio.h>
//This program will execute an executable file of another C program which takes a number as command line argument
int main(int argc, char *argv[])
{
	printf("Executing executable file of another C program.....\n");
	int ret = execl("./executable","executable","5",NULL);
	if(ret==-1)
	{
		perror("EXECL ERROR");
		return 1;
	}
	return 0;
}
