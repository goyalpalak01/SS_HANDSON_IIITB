#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int main()
{
	struct ticket{
		int train_number;
		int ticket_number;
	}t[3];

	int fd = open("Records.txt",O_RDWR|O_CREAT|O_TRUNC,0744);
	if(fd==-1)
	{
		perror("OPEN ERROR");
		return -1;
	}
	for(int i=1;i<=3;i++)
	{
		t[i-1].train_number=i;
		t[i-1].ticket_number=0;
	}
	
	write(fd,&t,sizeof(t));

	close(fd);
	return 0;
}