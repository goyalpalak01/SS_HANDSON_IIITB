#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main()
{
	int pipefd[2],ret;
	char buf[]="Hello World!!\n";
	char read_buf[30];

	ret = pipe(pipefd); //creates a pipe and return two fds in pipefd array
	if(ret==-1)
	{
		perror("PIPE ERROR");
		return -1;
	}

	//write to the pipe

	int bytes_written = write(pipefd[1],buf,strlen(buf));
	if(bytes_written==-1)
	{
		perror("WRITE ERROR");
		return -1;
	}
	else
	{
		printf("No. of bytes written to pipe = %d\n",bytes_written);
	}

	//read from the pipe

	int bytes_read = read(pipefd[0], read_buf,sizeof(read_buf));
	if(bytes_read==-1)
	{
		perror("READ ERROR");
		return -1;
	}
	else
	{
		printf("Read %d bytes from the pipe and data read = %s\n",bytes_read,read_buf);
	}
	return 0;

}