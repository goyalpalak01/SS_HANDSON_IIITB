#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <time.h>

int main()
{
	//create a new message queue
	int qid = msgget((key_t)1234,IPC_CREAT|0666);
	if(qid==-1)
	{
		perror("MSGGET ERROR");
		return -1;
	}
	
	struct msqid_ds qinfo;
	
	int ret = msgctl(qid,IPC_STAT,&qinfo); //to perform control operations on message queue
	if(ret==-1)
	{
		perror("MSGCTL ERROR");
		return -1;
	}
	else
	{	

		printf("****MESSAGE QUEUE STATS****\n");
		printf("Access Permissions= 0%o\n",qinfo.msg_perm.mode);
		printf("UID of owner = %ld\n",(long) qinfo.msg_perm.uid);
		printf("GID of owner = %ld\n",(long) qinfo.msg_perm.gid);
		printf("Time of last message sent = %s\n", ctime(&qinfo.msg_stime));
		printf("Time of last message received = %s\n", ctime(&qinfo.msg_rtime));
		printf("Time of last change = %s\n", ctime(&qinfo.msg_ctime));
		printf("Size of the queue = %luB\n", qinfo.msg_cbytes);
		printf("Current number of messages in queue = %ld\n", (long)qinfo.msg_qnum);
		printf("Maximum number of bytes allowed in queue = %ld\n", (long)qinfo.msg_qbytes);
		printf("PID of last message sent= %ld\n", (long)qinfo.msg_lspid);
		printf("PID of last message received= %ld\n", (long)qinfo.msg_lrpid);
		

	}
	return 0;
}