#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <time.h>
int main(int argc,const char *argv[])
{
	struct stat st_buf;
	const char *filename = argv[1];
	int fd = open(filename, O_RDONLY);
	if(fd==-1)
	{
		perror("OPEN FILE ERROR");
		return 1;
	}
	
	int var = fstat(fd, &st_buf);
	if(var==-1)
	{
		perror("ERROR WHILE RETRIEVING STATS");
		return 2;
	}
	else
	{
		printf("INODE NO. of the file = %ld\n", (long) st_buf.st_ino);
		printf("No. of Hard Links = %ld\n", (long) st_buf.st_nlink);
		printf("User ID of owner = %ld\n", (long) st_buf.st_uid);
		printf("Group ID of owner = %ld\n", (long) st_buf.st_gid);
		printf("Total size of file = %ld bytes\n", (long) st_buf.st_size);
		printf("Preferred Block Size for I/O = %ld bytes\n", (long) st_buf.st_blksize);
		printf("No. of 512B blocks allocated = %ld\n", (long) st_buf.st_blocks);
		printf("Last Access Time = %s", ctime(&st_buf.st_atime));
		printf("Last Modification Time = %s", ctime(&st_buf.st_mtime));
		printf("Last Change Time = %s", ctime(&st_buf.st_ctime));

	}
	close(fd);
	return 0;
}


