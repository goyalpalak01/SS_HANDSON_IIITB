#include <stdio.h>
#include <sched.h>

int main()
{
	int max,min;

	max = sched_get_priority_max(SCHED_RR);
	if(max==-1)
	{
		perror("ERROR");
		return 1;
	}
	printf("Maximum priority value for SCHED_RR policy = %d\n",max);

	min = sched_get_priority_min(SCHED_RR);
	if(min==-1)
	{
		perror("ERROR");
		return 1;
	}
	printf("Minimum priority value for SCHED_RR policy = %d\n",min);
	return 0;
}