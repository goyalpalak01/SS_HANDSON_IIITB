#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

int main()
{
	struct ticket{
		int train_number;
		int ticket_number;
	}t;
	int n;
	int fd = open("Records.txt",O_RDWR);
	if(fd==-1)
	{
		perror("OPEN ERROR");
		return -1;
	}

	struct flock lock;
	lock.l_type = F_RDLCK;
	lock.l_whence= SEEK_SET;
	lock.l_pid=getpid();
	printf("Enter the train number{1,2,3} for which you want to read current ticket number:");
	scanf("%d",&n);
	switch(n)
	{
		case 1: //train number 1
			read(fd,&t,sizeof(t));
			lock.l_start=0;
			lock.l_len= sizeof(t);
			break;
		case 2://train number 2
			lseek(fd,sizeof(t),SEEK_CUR);
			read(fd,&t,sizeof(t));
			lock.l_start=8;
			lock.l_len= sizeof(t);
			break;
		case 3: //train number 3
			lseek(fd,2*sizeof(t),SEEK_CUR);
			read(fd,&t,sizeof(t));
			lock.l_start=16;
			lock.l_len= sizeof(t);
			break;
		default:
			printf("INVALID TRAIN NUMBER\n");
			return -1;

	}
	fcntl(fd,F_SETLKW,&lock);
	printf("Current ticket number for Train %d = %d\n",t.train_number,t.ticket_number);
	printf("Press Enter to exit:\n");
	getchar();
	getchar();
	lock.l_type=F_UNLCK;
	fcntl(fd,F_SETLK,&lock);
	close(fd);
	return 0;
}