#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc, const char *argv[])
{
	int fd;
	const char *filename = argv[1];
	fd= creat(filename,0644);
	printf("File descriptor returned by creat() system call: %d\n",fd);
	if(fd==-1)
		perror("ERROR");
			
	return 0;
}

