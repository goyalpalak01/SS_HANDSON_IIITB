#include <stdio.h>
#include <unistd.h>

//execle()
int main()
{
	char * ls_env[]={"PATH=/bin",NULL};
	printf("Calling execle() to list the contents...\n");
	
	int ret = execle("/bin/ls","ls","-Rl",NULL,ls_env);
	if(ret==-1)
	{
		perror("EXECLE");
		return 1;
	}
	return 0;
}