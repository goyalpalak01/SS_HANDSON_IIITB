#include <stdio.h>
#include <sched.h>
#include <unistd.h>

int main()
{	
	int policy = sched_getscheduler(getpid()); //get scheduling policy

	switch(policy)
	{
		case SCHED_OTHER:
				printf("Scheduling policy of this process: NORMAL (SCHED_OTHER)\n");
				break;
		case SCHED_FIFO:
				printf("Scheduling policy of this process: First-In-First-Out (SCHED_FIFO)\n");
				break;
		case SCHED_RR:
				printf("Scheduling policy of this process: Round Robin (SCHED_RR)\n");
				break;
		case -1:
				perror("ERROR in sched_getscheduler()");
				break;
		default:
				printf("UNKNOWN POLICY\n");
	}
	//set scheduling policy
	struct sched_param sp;
	sp.sched_priority =19;

	int ret = sched_setscheduler(getpid(),SCHED_RR,&sp);
	if(ret==-1)
	{
		perror("ERROR in sched_setscheduler()");
		return 1;
	}
	else
	{
		printf("Modified Scheduling policy :Round Robin (SCHED_RR)\n");
	}
	
	return 0;
}