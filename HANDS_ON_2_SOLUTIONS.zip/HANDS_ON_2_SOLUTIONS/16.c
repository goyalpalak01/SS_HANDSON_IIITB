#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

int main()
{
	int fd1[2],fd2[2],ret1,ret2;
	char msg1[]="This message is from parent to child\n";
	char msg2[]="This message is from child to parent\n";
	char read_buf1[100],read_buf2[100];

	//creating two pipes for two way communication. fd1: parent to child ,fd2: child to parent
	ret1 = pipe(fd1);
	if(ret1==-1)
	{
		perror("PIPE1 ERROR");
		return -1;
	}
	ret2 = pipe(fd2);
	if(ret2==-1)
	{
		perror("PIPE2 ERROR");
		return -1;
	}

	int pid = fork(); //creates child process
	if(pid==-1)
	{
		perror("FORK ERROR");
		return -1;
	}
	else if(pid==0) //child process
	{
		close(fd1[1]); //close writing end of pipe1
		close(fd2[0]); //close reading end of pipe2
		read(fd1[0],read_buf1,sizeof(read_buf1));	//read msg from pipe 1
		printf("CHILD HERE : RECEIVED DATA FROM PARENT --> %s\n",read_buf1);

		write(fd2[1],msg2,strlen(msg2));//write msg to pipe2
		printf("CHILD HERE : DATA SENT TO PARENT\n");

	}
	else //parent process
	{
		close(fd1[0]); //close reading end of pipe1
		close(fd2[1]); //close writing end of pipe2

		write(fd1[1],msg1,strlen(msg1)); //write msg to pipe 1
		printf("PARENT HERE : DATA SENT TO CHILD\n");

		read(fd2[0],read_buf2,sizeof(read_buf2)); //read msg from pipe2
		printf("PARENT HERE : RECEIVED DATA FROM CHILD --> %s\n",read_buf2);
	}
	return 0;
}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 16.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out
PARENT HERE : DATA SENT TO CHILD
CHILD HERE : RECEIVED DATA FROM PARENT --> This message is from parent to child

CHILD HERE : DATA SENT TO PARENT
PARENT HERE : RECEIVED DATA FROM CHILD --> This message is from child to parent

*/





