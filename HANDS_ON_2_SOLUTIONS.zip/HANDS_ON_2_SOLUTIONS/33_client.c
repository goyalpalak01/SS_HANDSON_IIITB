//Client program  which takes input as array of numbers from the user and sends it to server
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <string.h>

int main(int argc, char const *argv[])
{
	int sockfd_client; //file descriptor that refers to endpoint

	sockfd_client = socket(AF_INET,SOCK_STREAM,0);//create an endpoint for communication. SOCK_STREAM for TCP. Protocol value for IP =0
										   // AF_INET for IPv4
	if(sockfd_client==-1)
	{
		perror("SOCKET ERROR");
		return -1;
	}

	//initiate the connection on a socket using connect()
	struct sockaddr_in server_addr; /*Each socket domain requires its own address format.
									In the AF_INET domain, the address is specified using a structure called sockaddr_in(man 7 ip)*/

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(9734);//convert values b/w host and network byte order
	server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");//converts Internet host address into netwrk byte order

	printf("Establishing connection with server.....\n");
	int ret = connect(sockfd_client,(struct sockaddr *)&server_addr,sizeof(server_addr));
	if(ret==-1)
	{
		perror("CONNECTION FAILED");
		return -1;
	}
	else
		printf("****CONNECTION ESTABLISHED****\n");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	int input_arr[7],output_arr[7],i=0;
	printf("Enter 7 numbers(separated by space) to be sorted:\n");
	
	while(i<7)
	{
		scanf("%d",&input_arr[i]);
		i++;
	}
	printf("Sending the numbers to the server for sorting...\n");
	write(sockfd_client,&input_arr,sizeof(input_arr));
	printf("Received sorted sequence:\n");
	read(sockfd_client, &output_arr,sizeof(output_arr));

	for(i=0;i<7;i++)
	{
		printf("%d\t",output_arr[i]);
	}

	close(sockfd_client);
	printf("\nEXITING..\n");
	return 0;
}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 33_client.c -o client
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./client
Establishing connection with server.....
****CONNECTION ESTABLISHED****
Enter 7 numbers(separated by space) to be sorted:
3 5 1 2 8 6 9
Sending the numbers to the server for sorting...
Corresponding sorted sequence:
1	2	3	5	6	8	9	
EXITING..
*/