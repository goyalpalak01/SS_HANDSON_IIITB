#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>

int main(int argc, const char *argv[])
{
	const char *filename = argv[1];
	struct stat sbuf;
	int fd = open(filename,O_RDONLY);
	if(fd==-1)
	{
		perror("OPEN ERROR");
		return 1;
	}

	int ret =fstat(fd,&sbuf);
	if(ret==-1)
	{
		perror("FSTAT ERROR");
		return 1;
	}
	if(S_ISREG(sbuf.st_mode))      //Alternatively we can use st_mode & S_IFMT mask to get file type ---> S_IFREG for regular file
		printf("REGULAR FILE\n");
	else if(S_ISBLK(sbuf.st_mode))
		printf("BLOCK DEVICE\n");
	else if(S_ISSOCK(sbuf.st_mode))
		printf("SOCKET\n");
	else if(S_ISLNK(sbuf.st_mode))
		printf("SYMBOLIC LINK\n");
	else if(S_ISDIR(sbuf.st_mode))
		printf("DIRECTORY\n");
	else if(S_ISCHR(sbuf.st_mode))
		printf("CHARACTER DEVICE\n");
	else if(S_ISFIFO(sbuf.st_mode))
		printf("FIFO\n");
	else
		printf("UNKNOWN FILE TYPE\n");

	close(fd);
	return 0;
}


