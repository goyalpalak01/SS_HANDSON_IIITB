#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{	
	int n1,n2,n3,wait_ret,wstatus;
	printf("Starting the program!!!\n");

	n1 = fork(); //first child
	if(n1 > 0)//Parent process
	{
		printf("Parent Process ID = %d\n",getpid());
		printf("Child PID's are:\n");
		printf("First child ID = %d\n",n1);
		n2 = fork(); //second child
		if(n2 > 0)
		{
			printf("Second child ID = %d\n",n2);
			n3 = fork(); //third child
			if(n3 > 0)
			{
				printf("Third child ID = %d\n",n3);
				printf("Parent waiting for Second child to terminate:\n");
				wait_ret = waitpid(n2,&wstatus,0);
				if(WIFEXITED(wstatus))//returns true if child terminate normally
				{
					printf("Parent succesfully waited for Second child; Return value is %d\n",wait_ret );
				}
			}
			else if(n3==0)
			{
				sleep(5);
				printf("Third child terminated!!\n");
			}
		}
		else if(n2==0)
		{
			sleep(15);
			printf("Second child terminated!!\n");
		}

	}

	else if(n1==0)
	{
		sleep(5);
		printf("First child terminated!!\n");
	}
	return 0;
}
