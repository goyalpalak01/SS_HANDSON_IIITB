//SIGFPE(all arithmetic errors) using sigaction
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>

void mySig_Handler(int signum)
{
	printf("\nCaught SIGFPE signal and exiting...\n");
	exit(0);
}

int main()
{
	struct sigaction sa;
	sa.sa_handler = &mySig_Handler;

	sigaction(SIGFPE,&sa,NULL);

	//Generating SIGFPE signal by dividing by 0
	int n;
	printf("Enter any number:\n");
	scanf("%d",&n);
	printf("Dividing input number by 0...\n");
	int m = n/0;

	return 0;
}