#include <stdio.h>
#include <unistd.h>

//execvp()
int main()
{
	char * argv[]={"ls","-Rl",NULL};
	printf("Calling execvp() to list the contents...\n");
	
	int ret = execvp("ls",argv);
	if(ret==-1)
	{
		perror("EXECVP");
		return 1;
	}
	return 0;
}