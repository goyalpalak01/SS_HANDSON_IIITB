#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdlib.h>
int main()
{	
	char buf[1024];
	fd_set rd;
	FD_ZERO(&rd);//removes all fds from specified set
	FD_SET(0, &rd);//watch fd 0 to see when it has input

	struct timeval t;
	t.tv_sec=10; //seconds
	t.tv_usec=0;//microseconds

	int ret = select(1,&rd,NULL,NULL,&t);
	
	if(ret==-1)
		perror("SELECT ERROR");
	else if(ret)
	{
		read(0,buf,sizeof(buf));
		printf("Data is available now\n");
	}
	else
		printf("No data within 10 seconds\n");
	return 0;


}
