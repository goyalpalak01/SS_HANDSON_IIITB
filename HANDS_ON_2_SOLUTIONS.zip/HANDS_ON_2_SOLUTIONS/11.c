//using sigaction()
#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int main()
{
	struct sigaction sa;

	//Ignore SIGINT signal
	sa.sa_handler = SIG_IGN;
	sigaction(SIGINT,&sa,NULL);

	printf("Any interrupt from keyboard(SIGINT) will be ignored!!!\n");
	sleep(10);

	printf("Resetting SIGINT action to default:\n");
	//Reset the default action
	sa.sa_handler = SIG_DFL;
	sigaction(SIGINT,&sa,NULL);

	sleep(10);
	return 0;

}
/*palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ gcc 11.c
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ ./a.out
Any interrupt from keyboard(SIGINT) will be ignored!!!
^C
^C
^C
Resetting SIGINT action to default:
^C
palak@palak-VirtualBox:~/SSD_Assignments/MT2020026_2$ 
*/